# --8<-- [start:grid]
<div class="grid cards" markdown>
# --8<-- [end:grid]

# --8<-- [start:grid-end]
</div>
# --8<-- [end:grid-end]

# --8<-- [start:twocolumn-start]
<div class="twocolumn" markdown>
<div class="div1" markdown>
# --8<-- [end:twocolumm-start]

# --8<-- [start:twocolumn2]
</div>
<div class="div2" markdown>
# --8<-- [end:twocolumn2]

# --8<-- [start:twocolumn-end]
</div>
</div>
# --8<-- [end:twocolumn-end]
